function calcularTriangulo() {
    const ladoX = parseFloat(document.getElementById('ladoX').value);
    const ladoY = parseFloat(document.getElementById('ladoY').value);
    const ladoZ = parseFloat(document.getElementById('ladoZ').value);
    const resultadoDiv = document.getElementById('resultadoTriangulo');

    if (isNaN(ladoX) || isNaN(ladoY) || isNaN(ladoZ) || ladoX <= 0 || ladoY <= 0 || ladoZ <= 0) {
        resultadoDiv.innerHTML = '<p style="color: red;">Por favor, insira valores válidos para todos os lados.</p>';
        return;
    }

    let tipoTriangulo = '';
    if (ladoX < ladoY + ladoZ && ladoY < ladoX + ladoZ && ladoZ < ladoX + ladoY) {
        if (ladoX === ladoY && ladoY === ladoZ) {
            tipoTriangulo = 'Triângulo Equilátero';
        } else if (ladoX === ladoY || ladoX === ladoZ || ladoY === ladoZ) {
            tipoTriangulo = 'Triângulo Isósceles';
        } else {
            tipoTriangulo = 'Triângulo Escaleno';
        }
        resultadoDiv.innerHTML = `<p>Os lados formam um: <strong>${tipoTriangulo}</strong></p>`;
    } else {
        resultadoDiv.innerHTML = '<p>Os valores <strong>NÃO</strong> formam um triângulo.</p>';
    }
}

function calcularIMC() {
    const peso = parseFloat(document.getElementById('pesoIMC').value);
    const altura = parseFloat(document.getElementById('alturaIMC').value);
    const resultadoDiv = document.getElementById('resultadoIMC');

    if (isNaN(peso) || isNaN(altura) || peso <= 0 || altura <= 0) {
        resultadoDiv.innerHTML = '<p style="color: red;">Por favor, insira valores válidos para peso e altura.</p>';
        return;
    }

    const imc = peso / (altura * altura);
    let classificacao = '';

    if (imc < 18.5) {
        classificacao = 'Abaixo do peso';
    } else if (imc >= 18.5 && imc <= 24.9) {
        classificacao = 'Peso normal';
    } else if (imc >= 25 && imc <= 29.9) {
        classificacao = 'Sobrepeso';
    } else if (imc >= 30 && imc <= 34.9) {
        classificacao = 'Obesidade grau 1';
    } else if (imc >= 35 && imc <= 39.9) {
        classificacao = 'Obesidade grau 2';
    } else {
        classificacao = 'Obesidade grau 3';
    }

    resultadoDiv.innerHTML = `
        <p>Seu IMC é: <strong>${imc.toFixed(2)}</strong></p>
        <p>Classificação: <strong>${classificacao}</strong></p>
    `;
}

function calcularImpostoCarro() {
    const anoCarro = parseInt(document.getElementById('anoCarro').value);
    const valorTabelaCarro = parseFloat(document.getElementById('valorTabelaCarro').value);
    const resultadoDiv = document.getElementById('resultadoImpostoCarro');

    if (isNaN(anoCarro) || isNaN(valorTabelaCarro) || anoCarro <= 0 || valorTabelaCarro <= 0) {
        resultadoDiv.innerHTML = '<p style="color: red;">Por favor, insira valores válidos para ano e valor.</p>';
        return;
    }

    let imposto = 0;
    if (anoCarro < 1990) {
        imposto = valorTabelaCarro * 0.01;
    } else {
        imposto = valorTabelaCarro * 0.015;
    }

    resultadoDiv.innerHTML = `<p>Imposto a ser pago: <strong>R$ ${imposto.toFixed(2)}</strong></p>`;
}

function calcularSalario() {
    const salarioAntigo = parseFloat(document.getElementById('salarioAntigo').value);
    const cargo = document.getElementById('cargoFuncionario').value;
    const resultadoDiv = document.getElementById('resultadoSalario');

    if (isNaN(salarioAntigo) || salarioAntigo <= 0 || cargo === '') {
        resultadoDiv.innerHTML = '<p style="color: red;">Por favor, insira um salário válido e selecione um cargo.</p>';
        return;
    }

    let percentualAumento = 0;
    switch (cargo) {
        case 'Gerente':
            percentualAumento = 0.10;
            break;
        case 'Engenheiro':
            percentualAumento = 0.20;
            break;
        case 'Tecnico':
            percentualAumento = 0.30;
            break;
        case 'Outro':
            percentualAumento = 0.40;
            break;
        default:
            percentualAumento = 0;
            break;
    }

    const aumento = salarioAntigo * percentualAumento;
    const novoSalario = salarioAntigo + aumento;
    const diferenca = novoSalario - salarioAntigo;

    resultadoDiv.innerHTML = `
        <p>Salário Antigo: <strong>R$ ${salarioAntigo.toFixed(2)}</strong></p>
        <p>Novo Salário: <strong>R$ ${novoSalario.toFixed(2)}</strong></p>
        <p>Diferença: <strong>R$ ${diferenca.toFixed(2)}</strong></p>
    `;
}

function calcularCreditoBancario() {
    const saldoMedio = parseFloat(document.getElementById('saldoMedio').value);
    const resultadoDiv = document.getElementById('resultadoCreditoBancario');

    if (isNaN(saldoMedio) || saldoMedio < 0) {
        resultadoDiv.innerHTML = '<p style="color: red;">Por favor, insira um saldo médio válido.</p>';
        return;
    }

    let valorCredito = 0;
    let mensagemCredito = '';

    if (saldoMedio >= 0 && saldoMedio <= 200) {
        valorCredito = 0;
        mensagemCredito = 'Nenhum crédito disponível.';
    } else if (saldoMedio >= 201 && saldoMedio <= 400) {
        valorCredito = saldoMedio * 0.20;
        mensagemCredito = '20% do saldo médio.';
    } else if (saldoMedio >= 401 && saldoMedio <= 600) {
        valorCredito = saldoMedio * 0.30;
        mensagemCredito = '30% do saldo médio.';
    } else if (saldoMedio > 601) {
        valorCredito = saldoMedio * 0.40;
        mensagemCredito = '40% do saldo médio.';
    }

    resultadoDiv.innerHTML = `
        <p>Saldo Médio: <strong>R$ ${saldoMedio.toFixed(2)}</strong></p>
        <p>Valor do Crédito: <strong>R$ ${valorCredito.toFixed(2)}</strong> (${mensagemCredito})</p>
    `;
}

function calcularPedidoLanchonete() {
    const item = document.getElementById('itemLanchonete').value;
    const quantidade = parseInt(document.getElementById('quantidadeLanchonete').value);
    const resultadoDiv = document.getElementById('resultadoLanchonete');

    if (item === '' || isNaN(quantidade) || quantidade <= 0) {
        resultadoDiv.innerHTML = '<p style="color: red;">Por favor, selecione um item e insira uma quantidade válida.</p>';
        return;
    }

    let precoUnitario = 0;
    switch (item) {
        case 'Cachorro quente':
            precoUnitario = 11.00;
            break;
        case 'Bauru':
            precoUnitario = 8.50;
            break;
        case 'Misto Quente':
            precoUnitario = 8.00;
            break;
        case 'Hamburger':
            precoUnitario = 9.00;
            break;
        case 'Cheeseburger':
            precoUnitario = 10.00;
            break;
        case 'Refrigerante':
            precoUnitario = 4.50;
            break;
        default:
            precoUnitario = 0;
            break;
    }

    const valorTotal = precoUnitario * quantidade;

    resultadoDiv.innerHTML = `
        <p>Item: <strong>${item}</strong></p>
        <p>Quantidade: <strong>${quantidade}</strong></p>
        <p>Valor Total a Pagar: <strong>R$ ${valorTotal.toFixed(2)}</strong></p>
    `;
}

function calcularVenda() {
    const precoEtiqueta = parseFloat(document.getElementById('precoEtiqueta').value);
    const condicaoPagamento = document.getElementById('condicaoPagamento').value;
    const resultadoDiv = document.getElementById('resultadoVenda');

    if (isNaN(precoEtiqueta) || precoEtiqueta <= 0 || condicaoPagamento === '') {
        resultadoDiv.innerHTML = '<p style="color: red;">Por favor, insira o preço e selecione a condição de pagamento.</p>';
        return;
    }

    let valorPago = 0;
    let detalhesPagamento = '';

    switch (condicaoPagamento) {
        case 'a':
            valorPago = precoEtiqueta * 0.90;
            detalhesPagamento = 'À vista em dinheiro ou cheque (10% de desconto)';
            break;
        case 'b':
            valorPago = precoEtiqueta * 0.85;
            detalhesPagamento = 'À vista no cartão de crédito (15% de desconto)';
            break;
        case 'c':
            valorPago = precoEtiqueta;
            detalhesPagamento = 'Em duas vezes (preço normal, sem juros)';
            break;
        case 'd':
            valorPago = precoEtiqueta * 1.10;
            detalhesPagamento = 'Em duas vezes (preço normal + 10% de juros)';
            break;
        default:
            valorPago = 0;
            detalhesPagamento = 'Condição de pagamento inválida.';
            break;
    }

    resultadoDiv.innerHTML = `
        <p>Preço de Etiqueta: <strong>R$ ${precoEtiqueta.toFixed(2)}</strong></p>
        <p>Condição de Pagamento: <strong>${detalhesPagamento}</strong></p>
        <p>Valor Final a Pagar: <strong>R$ ${valorPago.toFixed(2)}</strong></p>
    `;
}

function calcularSalarioProfessor() {
    const nivelProfessor = document.getElementById('nivelProfessor').value;
    const qtdAulasSemana = parseInt(document.getElementById('qtdAulasSemana').value);
    const resultadoDiv = document.getElementById('resultadoSalarioProfessor');

    if (nivelProfessor === '' || isNaN(qtdAulasSemana) || qtdAulasSemana < 0) {
        resultadoDiv.innerHTML = '<p style="color: red;">Por favor, selecione o nível do professor e insira a quantidade de aulas.</p>';
        return;
    }

    let valorHoraAula = 0;
    let nivelDesc = '';

    switch (nivelProfessor) {
        case '1':
            valorHoraAula = 12.00;
            nivelDesc = 'Nível 1';
            break;
        case '2':
            valorHoraAula = 17.00;
            nivelDesc = 'Nível 2';
            break;
        case '3':
            valorHoraAula = 25.00;
            nivelDesc = 'Nível 3';
            break;
        default:
            valorHoraAula = 0;
            break;
    }

    const salario = valorHoraAula * qtdAulasSemana * 4.5;

    resultadoDiv.innerHTML = `
        <p>Nível do Professor: <strong>${nivelDesc}</strong></p>
        <p>Horas/Aula na Semana: <strong>${qtdAulasSemana}</strong></p>
        <p>Salário Mensal Estimado: <strong>R$ ${salario.toFixed(2)}</strong></p>
    `;
}