function getNumberValue(id) {
    return parseFloat(document.getElementById(id).value);
}

function getStringValue(id) {
    return document.getElementById(id).value;
}

function formatCurrency(value) {
    return value.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function calcularAreaTerreno() {
    const largura = getNumberValue('q1Largura');
    const comprimento = getNumberValue('q1Comprimento');
    const resultadoElement = document.getElementById('resultadoQ1');

    if (isNaN(largura) || isNaN(comprimento) || largura < 0 || comprimento < 0) {
        resultadoElement.textContent = 'Erro: Insira números positivos.';
        return;
    }
    resultadoElement.textContent = `Área: ${formatCurrency(largura * comprimento)} m²`;
}

function calcularFerraduras() {
    const cavalos = getNumberValue('q2Cavalos');
    const resultadoElement = document.getElementById('resultadoQ2');

    if (isNaN(cavalos) || cavalos < 0) {
        resultadoElement.textContent = 'Erro: Insira um número de cavalos válido.';
        return;
    }
    resultadoElement.textContent = `Ferraduras necessárias: ${cavalos * 4}`;
}

function calcularPadaria() {
    const paes = getNumberValue('q3Paes');
    const broas = getNumberValue('q3Broas');
    const resultadoElement = document.getElementById('resultadoQ3');

    if (isNaN(paes) || isNaN(broas) || paes < 0 || broas < 0) {
        resultadoElement.textContent = 'Erro: Insira quantidades válidas.';
        return;
    }

    const totalArrecadado = (paes * 0.12) + (broas * 1.50);
    const poupanca = totalArrecadado * 0.10;
    resultadoElement.innerHTML = `Arrecadado: R$ ${formatCurrency(totalArrecadado)}<br>Poupança: R$ ${formatCurrency(poupanca)}`;
}

function calcularDiasDeVida() {
    const nome = getStringValue('q4Nome').trim();
    const idade = getNumberValue('q4Idade');
    const resultadoElement = document.getElementById('resultadoQ4');

    if (nome === '' || isNaN(idade) || idade < 0) {
        resultadoElement.textContent = 'Erro: Insira nome e idade válidos.';
        return;
    }
    resultadoElement.textContent = `${nome.toUpperCase()}, VOCÊ JÁ VIVEU ${idade * 365} DIAS`;
}

function calcularLitrosGasolina() {
    const precoLitro = getNumberValue('q5PrecoLitro');
    const valorPagamento = getNumberValue('q5ValorPagamento');
    const resultadoElement = document.getElementById('resultadoQ5');

    if (isNaN(precoLitro) || isNaN(valorPagamento) || precoLitro <= 0 || valorPagamento < 0) {
        resultadoElement.textContent = 'Erro: Insira valores válidos.';
        return;
    }
    const litros = valorPagamento / precoLitro;
    resultadoElement.textContent = `Litros: ${litros.toFixed(2).replace('.', ',')}`;
}

function calcularValorRestaurante() {
    const pesoPrato = getNumberValue('q6PesoPrato');
    const resultadoElement = document.getElementById('resultadoQ6');

    if (isNaN(pesoPrato) || pesoPrato < 0) {
        resultadoElement.textContent = 'Erro: Insira um peso válido.';
        return;
    }
    resultadoElement.textContent = `Valor a pagar: R$ ${formatCurrency(pesoPrato * 12.00)}`;
}

function calcularDiasPassados() {
    const dia = getNumberValue('q7Dia');
    const mes = getNumberValue('q7Mes');
    const resultadoElement = document.getElementById('resultadoQ7');

    if (isNaN(dia) || isNaN(mes) || dia < 1 || dia > 31 || mes < 1 || mes > 12) {
        resultadoElement.textContent = 'Erro: Insira dia e mês válidos.';
        return;
    }
    resultadoElement.textContent = `Dias passados: ${((mes - 1) * 30) + dia}`;
}

function calcularValorCamisetas() {
    const pequenas = getNumberValue('q8Pequenas');
    const medias = getNumberValue('q8Medias');
    const grandes = getNumberValue('q8Grandes');
    const resultadoElement = document.getElementById('resultadoQ8');

    if (isNaN(pequenas) || isNaN(medias) || isNaN(grandes) || pequenas < 0 || medias < 0 || grandes < 0) {
        resultadoElement.textContent = 'Erro: Insira quantidades válidas.';
        return;
    }
    const total = (pequenas * 10) + (medias * 12) + (grandes * 15);
    resultadoElement.textContent = `Total arrecadado: R$ ${formatCurrency(total)}`;
}

function calcularDistanciaPontos() {
    const x1 = getNumberValue('q9X1');
    const y1 = getNumberValue('q9Y1');
    const x2 = getNumberValue('q9X2');
    const y2 = getNumberValue('q9Y2');
    const resultadoElement = document.getElementById('resultadoQ9');

    if (isNaN(x1) || isNaN(y1) || isNaN(x2) || isNaN(y2)) {
        resultadoElement.textContent = 'Erro: Insira coordenadas válidas.';
        return;
    }
    const distancia = Math.sqrt(Math.pow((x2 - x1), 2) + Math.pow((y2 - y1), 2));
    resultadoElement.textContent = `Distância: ${distancia.toFixed(2).replace('.', ',')}`;
}

function converterTempoTrabalho() {
    const totalDias = getNumberValue('q10TotalDias');
    const resultadoElement = document.getElementById('resultadoQ10');

    if (isNaN(totalDias) || totalDias < 0) {
        resultadoElement.textContent = 'Erro: Insira um número de dias válido.';
        return;
    }
    const anos = Math.floor(totalDias / 365);
    const diasRestantesAposAnos = totalDias % 365;
    const meses = Math.floor(diasRestantesAposAnos / 30);
    const diasFinais = diasRestantesAposAnos % 30;
    resultadoElement.textContent = `Tempo: ${anos} anos, ${meses} meses, ${diasFinais} dias.`;
}

function calcularSalario() {
    const salarioInicial = getNumberValue('q11SalarioInicial');
    const resultadoElement = document.getElementById('resultadoQ11');

    if (isNaN(salarioInicial) || salarioInicial < 0) {
        resultadoElement.textContent = 'Erro: Insira um salário inicial válido.';
        return;
    }
    const salarioComAumento = salarioInicial * 1.15;
    const salarioFinal = salarioComAumento * 0.92; // Desconta 8%
    resultadoElement.innerHTML = `Inicial: R$ ${formatCurrency(salarioInicial)}<br>Aumento: R$ ${formatCurrency(salarioComAumento)}<br>Final: R$ ${formatCurrency(salarioFinal)}`;
}

function decomporNumero() {
    const numero = getNumberValue('q12Numero');
    const resultadoElement = document.getElementById('resultadoQ12');

    if (isNaN(numero) || numero < 0 || numero > 999 || !Number.isInteger(numero)) {
        resultadoElement.textContent = 'Erro: Insira um número inteiro entre 0 e 999.';
        return;
    }
    const centena = Math.floor(numero / 100);
    const dezena = Math.floor((numero % 100) / 10);
    const unidade = numero % 10;
    resultadoElement.textContent = `CENTENA = ${centena} DEZENA = ${dezena} UNIDADE = ${unidade}`;
}

function calcularAreaPizza() {
    const raio = getNumberValue('q13RaioPizza');
    const pi = 3.14;
    const resultadoElement = document.getElementById('resultadoQ13');

    if (isNaN(raio) || raio < 0) {
        resultadoElement.textContent = 'Erro: Insira um raio válido.';
        return;
    }
    const area = pi * Math.pow(raio, 2);
    resultadoElement.textContent = `Área: ${formatCurrency(area)} cm²`;
}

function racharContaBar() {
    const valorConta = getNumberValue('q14ValorConta');
    const resultadoElement = document.getElementById('resultadoQ14');

    if (isNaN(valorConta) || valorConta < 0) {
        resultadoElement.textContent = 'Erro: Insira um valor de conta válido.';
        return;
    }
    const valorInteiroPorPessoa = Math.floor(valorConta / 3);
    const carlosPaga = valorInteiroPorPessoa;
    const andrePaga = valorInteiroPorPessoa;
    const felipePaga = valorConta - (carlosPaga + andrePaga);

    resultadoElement.innerHTML = `Carlos: R$ ${formatCurrency(carlosPaga)}<br>André: R$ ${formatCurrency(andrePaga)}<br>Felipe: R$ ${formatCurrency(felipePaga)}`;
}